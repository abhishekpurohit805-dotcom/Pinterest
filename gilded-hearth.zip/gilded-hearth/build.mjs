// Static site generator. Zero dependencies: `node build.mjs` writes ./dist (deployed by Vercel).
import fs from 'node:fs';
import { site, STYLE, nav, categories, images, articles, planned } from './content.mjs';

const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const catOf = s => categories.find(c => c.slug === s);
const fmt = d => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' });
const hue = s => [...String(s)].reduce((n, c) => n + c.charCodeAt(0), 0) % 30 + 28;
const strip = h => h.replace(/<[^>]+>/g, ' ');
const wordCount = a => strip([a.intro, ...a.sections.flatMap(s => [s.body, ...(s.pros || []), ...(s.cons || [])]), ...a.faq.flat()].filter(Boolean).join(' ')).split(/\s+/).filter(Boolean).length;

articles.sort((x, y) => y.date.localeCompare(x.date));
articles.forEach(a => { a.read = Math.max(1, Math.round(wordCount(a) / 200)); });

/* ---------- components ---------- */
// Image slot: shows /images/<key>.jpg; if the file is missing the warm placeholder remains.
const fig = (k, o = {}) => {
  const alt = o.alt ?? images[k]?.[0] ?? '';
  const img = o.none ? '' : `<img src="/images/${k}.jpg" alt="${esc(alt)}" loading="${o.eager ? 'eager' : 'lazy'}"${o.eager ? ' fetchpriority="high"' : ''} decoding="async" onerror="this.remove()">`;
  return `<figure class="ph" style="aspect-ratio:${o.ratio || '2/3'};--h:${hue(o.hk || k)}"${alt ? ` data-l="${esc(alt)}"` : ''}>${img}</figure>`;
};
const card = a => `<article class="card" data-s="${esc(`${a.title} ${a.desc} ${a.cats.join(' ')}`.toLowerCase())}"><a href="/blog/${a.slug}">${fig(a.hero, { ratio: '4/5' })}<p class="cat">${catOf(a.cats[0]).name}</p><h3>${esc(a.title)}</h3><p>${esc(a.dek)}</p><p class="meta"><span>${a.read} min read</span></p></a></article>`;
const soon = p => `<article class="card soon">${fig(null, { ratio: '4/5', none: 1, alt: '', hk: p.title })}<p class="cat">${catOf(p.cat).name}</p><h3>${esc(p.title)}</h3><p>${esc(p.desc)}</p><p class="meta"><span>Coming soon</span></p></article>`;
const catCard = c => `<a class="cat-card" href="/category/${c.slug}">${fig('cat-' + c.slug, { ratio: '3/4', alt: '' })}<span>${c.name}</span></a>`;
const proCon = s => `<div class="pc"><div><h3>Pros</h3><ul>${s.pros.map(x => `<li>${x}</li>`).join('')}</ul></div><div><h3>Cons</h3><ul>${s.cons.map(x => `<li>${x}</li>`).join('')}</ul></div></div>`;
const prod = p => { const ok = /^https?:/.test(p.url); return `<aside class="prod"><h3>${esc(p.name)}</h3><p>${esc(p.blurb)}</p><a class="btn go" href="${ok ? esc(p.url) : '#featured'}" rel="sponsored nofollow noopener"${ok ? ' target="_blank"' : ''}>View on Amazon</a><p class="disc">${site.disclosure}</p></aside>`; };
const faqList = a => a.faq.map(([q, x]) => `<details><summary>${q}</summary><p>${x}</p></details>`).join('');
const sec = (s, a) => `<section id="${s.id}"><h2>${s.h}</h2>${s.body || ''}${s.product ? prod(s.product) : ''}${s.pros ? proCon(s) : ''}${s.faq ? faqList(a) : ''}${s.img ? fig(s.img) : ''}</section>`;

const links = [['/', 'Home'], ...nav.map(([s, l]) => [`/category/${s}`, l]), ['/blog', 'Blog']];
const header = () => `<a class="skip" href="#main">Skip to content</a><header class="hd"><div class="wrap bar"><a class="logo" href="/">${site.name}</a><nav id="nav" aria-label="Primary">${links.map(([h, l]) => `<a href="${h}">${l}</a>`).join('')}</nav><a class="ico" href="/blog?search" aria-label="Search stories"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></a><button class="burger" aria-label="Menu" aria-expanded="false" aria-controls="nav"><span></span></button></div></header>`;
const footer = () => `<footer class="ft"><div class="wrap"><a class="logo" href="/">${site.name}</a><p>${site.disclosure}</p><nav aria-label="Footer">${[['About', '/about'], ['Contact', '/contact'], ['Privacy', '/privacy'], ['Terms', '/terms'], ['Affiliate Disclosure', '/affiliate-disclosure']].map(([n, h]) => `<a href="${h}">${n}</a>`).join('')}<a href="${site.pinterest}" rel="noopener">Pinterest</a><a href="${site.instagram}" rel="noopener">Instagram</a></nav><p>&copy; ${new Date().getFullYear()} ${site.name}</p></div></footer>`;
const newsletter = () => `<section class="news"><div class="wrap"><h2>Get The Finds Worth Saving</h2><p class="lead" style="margin-inline:auto">Fresh product discoveries, room inspiration, and useful ideas.</p><form action="${site.newsletterAction || '#'}" method="post"${site.newsletterAction ? '' : ` onsubmit="event.preventDefault();this.lastElementChild.textContent='Connect a provider in content.mjs'"`}><label class="sr" for="em">Email address</label><input id="em" type="email" name="email" placeholder="Your email" autocomplete="email" required><button class="btn go" type="submit">Subscribe</button></form></div></section>`;

const page = ({ path, title, desc, body, ld = [], noindex, og = 'website', img = 'lamp-reading' }) => {
  const url = site.url + path, im = `${site.url}/images/${img}.jpg`;
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}">${noindex ? '<meta name="robots" content="noindex,follow">' : ''}<link rel="canonical" href="${url}"><meta name="theme-color" content="#f8f3e8"><link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='14' fill='%23c8a04a'/%3E%3C/svg%3E">
<meta property="og:type" content="${og}"><meta property="og:site_name" content="${site.name}"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${url}"><meta property="og:image" content="${im}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${esc(title)}"><meta name="twitter:description" content="${esc(desc)}"><meta name="twitter:image" content="${im}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:opsz,wght@6..96,400..600&family=Hanken+Grotesk:wght@400;500;600&display=swap"><link rel="stylesheet" href="/style.css">${ld.map(o => `<script type="application/ld+json">${JSON.stringify(o).replace(/</g, '\\u003c')}</script>`).join('')}</head><body>${header()}${body}${footer()}<script>const b=document.querySelector('.burger'),n=document.getElementById('nav');b.onclick=()=>{const o=n.classList.toggle('open');b.setAttribute('aria-expanded',o);document.body.classList.toggle('lock',o)}</script></body></html>`;
};

/* ---------- page bodies ---------- */
const home = () => {
  const a = articles[0];
  const trending = ['lighting', 'bedroom', 'decor', 'desk-setup', 'organization', 'gift-ideas'].map(catOf);
  const latest = [...articles.map(card), ...planned.map(soon)].slice(0, 6).join('');
  const mas = [['lamp-desk', '2/3'], ['inspo-1', '1/1'], ['lamp-living', '3/4'], ['inspo-2', '2/3'], ['lamp-collage', '2/3'], ['inspo-3', '4/5'], ['inspo-4', '1/1']];
  return `<main id="main">
<section class="wrap hero"><div class="in"><h1>Finds Worth Saving.</h1><p class="lead">Beautiful products, cozy spaces, and clever finds curated for everyday life.</p><a class="btn" href="/blog">Explore Latest Finds</a></div>${fig('lamp-reading', { eager: 1, ratio: '4/5' })}</section>
<section class="wrap sec"><div class="sh"><h2>Trending categories</h2><a href="/categories">All categories</a></div><div class="cats">${trending.map(catCard).join('')}</div></section>
<section class="wrap sec"><div class="feat">${fig(a.feature, { ratio: '4/5' })}<div><h2>${esc(a.short)}</h2><p class="lead">${esc(a.dek)}</p><a class="btn" href="/blog/${a.slug}">Read The Story</a></div></div></section>
<section class="wrap sec"><div class="sh"><h2>Latest stories</h2><a href="/blog">View all</a></div><div class="grid">${latest}</div></section>
<section class="wrap sec"><div class="sh"><h2>Inspiration</h2><a href="${site.pinterest}" rel="noopener">Follow on Pinterest</a></div><div class="mas">${mas.map(([k, r]) => fig(k, { ratio: r })).join('')}</div></section>
${newsletter()}</main>`;
};

const articleBody = a => {
  const c = catOf(a.cats[0]);
  const rel = articles.filter(x => x !== a && x.cats.some(k => a.cats.includes(k))).slice(0, 3);
  return `<main id="main"><article class="art">
<nav class="crumb" aria-label="Breadcrumb"><a href="/">Home</a> / <a href="/blog">Blog</a> / <a href="/category/${c.slug}">${c.name}</a></nav>
<p class="cat"><a href="/category/${c.slug}">${c.name}</a></p>
<h1>${esc(a.title)}</h1>
<p class="meta"><time datetime="${a.date}">${fmt(a.date)}</time><span>${a.read} min read</span></p>
<p class="disc">${site.disclosure}</p>
${fig(a.hero, { eager: 1, ratio: '4/5' })}
<div class="intro">${a.intro}</div>
<nav class="toc" aria-label="Table of contents"><p class="toc-h">In this story</p><ol>${a.sections.map(s => `<li><a href="#${s.id}">${s.h}</a></li>`).join('')}</ol></nav>
${a.sections.map(s => sec(s, a)).join('')}
<aside class="cta"><h2>Save it for later</h2><p>Pin this story and come back when you are ready to style your own corner.</p><a class="btn" href="#featured">See the featured pick</a> <a class="btn ghost" href="/blog">More stories</a></aside>
<p class="disc">${site.disclosure} <a href="/affiliate-disclosure">Affiliate disclosure</a></p>
</article>
<section class="wrap rel"><h2>Keep reading</h2>${rel.length ? `<div class="grid">${rel.map(card).join('')}</div>` : `<p>More stories are on the way. Explore ${a.cats.map(k => `<a href="/category/${k}">${catOf(k).name}</a>`).join(', ')}.</p>`}</section></main>`;
};

// Starter legal text: have a lawyer review it before launch.
const pages = {
  about: ['About', `Meet the lifestyle journal behind ${site.name}.`, `<p class="lead">${site.name} is an independent lifestyle journal about beautiful, useful things for the home.</p><p>We write about cozy lighting, calm bedrooms, tidy desks, smart organization and gifts worth giving, and we link to products when we think they are worth a look.</p><p>Some of those links are affiliate links, which help support the site at no extra cost to you. Read our <a href="/affiliate-disclosure">affiliate disclosure</a> for details.</p>`],
  contact: ['Contact', `Get in touch with the ${site.name} team.`, `<p class="lead">Questions, corrections or ideas? We would love to hear from you.</p><p>Email us at <a href="mailto:${site.email}">${site.email}</a>.</p>`],
  privacy: ['Privacy', `How ${site.name} collects and uses information.`, `<p>This policy explains what information ${site.name} collects and how it is used.</p><h2>Information we collect</h2><p>If you subscribe to our newsletter, we collect your email address. Like most websites, we may also collect basic, aggregated usage data, such as which pages are visited, through analytics tools.</p><h2>Cookies and third parties</h2><p>Third-party services, including retailers such as Amazon and social platforms such as Pinterest, may set their own cookies when you follow links to their sites. Their privacy policies apply there.</p><h2>Your choices</h2><p>You can unsubscribe from emails at any time, and you can contact us at ${site.email} to ask about your data.</p>`],
  terms: ['Terms', `The terms for using ${site.name}.`, `<p>By using ${site.name} you agree to these terms.</p><h2>Content</h2><p>Our articles are for general inspiration and information. Product details, prices, ratings and availability are controlled by retailers and change often, so please check the listing before you buy.</p><h2>Third-party links</h2><p>We link to other websites and are not responsible for their content or practices. Some links are affiliate links.</p><h2>Ownership</h2><p>Unless noted, the text and images on this site belong to ${site.name} and may not be reproduced without permission.</p>`],
  'affiliate-disclosure': ['Affiliate Disclosure', `How affiliate links work on ${site.name}.`, `<p class="lead">${site.disclosure}</p><p>Some links on ${site.name} are affiliate links. If you click one and make a purchase, we may receive a small commission from the retailer. It never changes the price you pay.</p><p>Prices, ratings and availability are set by the retailer and can change, so please check the listing before you buy.</p>`],
};

/* ---------- build ---------- */
fs.rmSync('dist', { recursive: true, force: true });
fs.mkdirSync('dist', { recursive: true });
if (fs.existsSync('public')) fs.cpSync('public', 'dist', { recursive: true });
fs.copyFileSync('style.css', 'dist/style.css');

const urls = [];
const emit = (path, o) => {
  const f = path === '/' ? 'dist/index.html' : `dist${path}.html`;
  fs.mkdirSync(f.slice(0, f.lastIndexOf('/')), { recursive: true });
  fs.writeFileSync(f, page({ path, ...o }));
  if (!o.noindex) urls.push([path, o.lastmod]);
};
const ctx = 'https://schema.org';

emit('/', { title: `${site.name} | Finds Worth Saving`, desc: 'Beautiful products, cozy spaces, and clever finds curated for everyday life.', body: home(), ld: [{ '@context': ctx, '@type': 'WebSite', name: site.name, url: site.url + '/' }] });

emit('/blog', { title: `Latest Stories | ${site.name}`, desc: `Product discoveries, room inspiration and useful ideas from ${site.name}.`, body: `<main id="main" class="wrap sec"><h1>Latest Stories</h1><p class="lead">Product discoveries, room inspiration and useful ideas.</p><label class="sr" for="q">Search stories</label><input id="q" class="search" type="search" placeholder="Search stories"><div class="grid">${articles.map(card).join('')}</div></main><script>const q=document.getElementById('q'),c=[...document.querySelectorAll('[data-s]')];q.oninput=()=>c.forEach(x=>x.hidden=!x.dataset.s.includes(q.value.toLowerCase()));if(location.search.includes('search'))q.focus()</script>` });

emit('/categories', { title: `Categories | ${site.name}`, desc: 'Browse cozy lighting, bedroom, decor, desk setup, organization, gift ideas and more.', body: `<main id="main" class="wrap sec"><h1>Categories</h1><p class="lead">Browse by room, mood or need.</p><div class="cats" style="margin-top:32px">${categories.map(catCard).join('')}</div></main>` });

categories.forEach(c => {
  const list = articles.filter(a => a.cats.includes(c.slug));
  emit(`/category/${c.slug}`, { title: `${c.name} Ideas & Finds | ${site.name}`, desc: `${c.blurb} Stories and finds from ${site.name}.`, noindex: !list.length, body: `<main id="main" class="wrap sec"><nav class="crumb" aria-label="Breadcrumb"><a href="/">Home</a> / <a href="/categories">Categories</a> / ${c.name}</nav><h1>${c.name}</h1><p class="lead">${c.blurb}</p><div style="height:32px"></div>${list.length ? `<div class="grid">${list.map(card).join('')}</div>` : '<p>New stories are on the way. <a href="/blog">Browse all stories</a>.</p>'}</main>` });
});

articles.forEach(a => {
  const c = catOf(a.cats[0]), url = `/blog/${a.slug}`;
  emit(url, {
    title: a.seoTitle, desc: a.desc, og: 'article', img: a.hero, lastmod: a.date, body: articleBody(a),
    ld: [
      { '@context': ctx, '@type': 'Article', headline: a.title, description: a.desc, image: [`${site.url}/images/${a.hero}.jpg`], datePublished: a.date, dateModified: a.date, author: { '@type': 'Organization', name: site.name }, publisher: { '@type': 'Organization', name: site.name }, mainEntityOfPage: site.url + url },
      { '@context': ctx, '@type': 'FAQPage', mainEntity: a.faq.map(([q, x]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: x } })) },
      { '@context': ctx, '@type': 'BreadcrumbList', itemListElement: [['Home', '/'], ['Blog', '/blog'], [c.name, `/category/${c.slug}`], [a.title, url]].map(([n, p], i) => ({ '@type': 'ListItem', position: i + 1, name: n, item: site.url + p })) },
    ],
  });
});

Object.entries(pages).forEach(([s, [t, d, b]]) => emit(`/${s}`, { title: `${t} | ${site.name}`, desc: d, body: `<main id="main" class="art sec"><h1>${t}</h1>${b}</main>` }));
emit('/404', { title: `Page not found | ${site.name}`, desc: 'This page could not be found.', noindex: 1, body: '<main id="main" class="center"><h1>Page not found</h1><p>That page has moved or never existed.</p><a class="btn" href="/">Back to home</a></main>' });

fs.writeFileSync('dist/sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(([p, d]) => `<url><loc>${site.url}${p}</loc>${d ? `<lastmod>${d}</lastmod>` : ''}</url>`).join('')}</urlset>`);
fs.writeFileSync('dist/robots.txt', `User-agent: *\nAllow: /\n\nSitemap: ${site.url}/sitemap.xml\n`);
fs.writeFileSync('IMAGE-PROMPTS.md', `# Image prompts\n\nSave each image as public/images/<name>.jpg (vertical 2:3, e.g. 1200x1800). Until a file exists, a warm placeholder is shown.\n\n${Object.entries(images).map(([k, [alt, p]]) => `## ${k}.jpg\n${p || alt}. ${STYLE}\n`).join('\n')}`);
console.log(`Built ${urls.length} indexable pages`);
