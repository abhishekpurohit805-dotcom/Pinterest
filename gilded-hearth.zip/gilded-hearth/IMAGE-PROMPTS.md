# Image prompts

Save each image as public/images/<name>.jpg (vertical 2:3, e.g. 1200x1800). Until a file exists, a warm placeholder is shown.

## lamp-bedroom.jpg
A cozy neutral bedroom at dusk, a mushroom table lamp glowing on a wooden nightstand beside stacked books, linen bedding and a chunky knit throw. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## lamp-desk.jpg
A tidy minimalist desk setup with a small mushroom table lamp glowing beside a laptop, a ceramic mug, a notebook and a trailing plant. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## lamp-living.jpg
A mushroom table lamp glowing on an oak console table in a warm neutral living room, styled with a ceramic vase and stacked art books. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## lamp-closeup.jpg
Close-up of a mushroom table lamp glowing softly, warm light falling across a textured plaster wall, shallow depth of field. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## lamp-reading.jpg
A cozy reading corner with a linen armchair, a chunky knit throw and a small side table holding a glowing mushroom lamp and a cup of tea. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## lamp-collage.jpg
A vertical three-panel photo collage of a mushroom lamp styled in a bedroom, on a desk and in a living room, consistent warm palette, thin ivory gutters. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-lighting.jpg
Warm lamplight glowing in a cozy neutral room. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-bedroom.jpg
Layered neutral bedding in soft morning light. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-decor.jpg
Ceramic vase and books styled on a wooden shelf. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-desk-setup.jpg
Calm minimalist desk with a plant and a lamp. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-organization.jpg
Neat woven baskets on a bright shelf. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-gift-ideas.jpg
Beautifully wrapped gifts with dried flowers. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-lifestyle.jpg
Morning coffee on a tray beside a sunlit window. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## cat-amazon-finds.jpg
Styled shelf of small home finds in warm light. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## inspo-1.jpg
Linen curtains and warm sunlight in a quiet bedroom. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## inspo-2.jpg
Stacked books, candle and tray on a walnut side table. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## inspo-3.jpg
Cozy window seat with cushions and a knit throw. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.

## inspo-4.jpg
Rattan pendant light over a neutral dining nook. Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.
