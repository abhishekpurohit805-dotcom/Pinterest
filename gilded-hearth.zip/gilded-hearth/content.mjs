// All editable content lives here. To add an article: copy the object in `articles`,
// change its fields, put its images in public/images/, then rebuild. The blog, category
// pages, related links and sitemap update automatically.

export const site = {
  name: 'Gilded Hearth',
  url: process.env.SITE_URL || 'https://www.example.com', // set SITE_URL in Vercel
  email: 'hello@example.com',
  pinterest: 'https://www.pinterest.com/',
  instagram: 'https://www.instagram.com/',
  newsletterAction: '', // paste your email provider's form URL
  // After Amazon Associates approval, add Amazon's required statement to the disclosure page.
  disclosure: 'We may earn a commission when you purchase through links on our site, at no extra cost to you.',
};

export const STYLE = 'Photorealistic premium interior photography, realistic materials and natural shadows, warm ambient lighting, sophisticated neutral interior, DSLR photography, 4K, editorial lifestyle magazine aesthetic, vertical Pinterest-friendly composition, no text, no watermark, no logos.';

export const nav = [['decor', 'Decor'], ['lighting', 'Lighting'], ['bedroom', 'Bedroom'], ['lifestyle', 'Lifestyle'], ['amazon-finds', 'Amazon Finds']];

export const categories = [
  { slug: 'lighting', name: 'Cozy Lighting', blurb: 'Warm, layered glows for slower evenings.' },
  { slug: 'bedroom', name: 'Bedroom', blurb: 'Calm, layered rooms made for rest.' },
  { slug: 'decor', name: 'Home Decor', blurb: 'Quiet details that make a room feel finished.' },
  { slug: 'desk-setup', name: 'Desk Setup', blurb: 'Tidy, inspiring places to work.' },
  { slug: 'organization', name: 'Organization', blurb: 'Pretty ways to keep everything in its place.' },
  { slug: 'gift-ideas', name: 'Gift Ideas', blurb: 'Thoughtful finds worth giving.' },
  { slug: 'lifestyle', name: 'Lifestyle', blurb: 'Useful little upgrades for everyday life.' },
  { slug: 'amazon-finds', name: 'Amazon Finds', blurb: 'Standout discoveries, hand-picked.' },
];

// key -> [alt text, optional prompt subject]. Save photos as public/images/<key>.jpg (2:3).
// The full AI prompt is subject + STYLE; IMAGE-PROMPTS.md is regenerated on every build.
export const images = {
  'lamp-bedroom': ['Mushroom lamp glowing on a wooden nightstand in a calm neutral bedroom', 'A cozy neutral bedroom at dusk, a mushroom table lamp glowing on a wooden nightstand beside stacked books, linen bedding and a chunky knit throw'],
  'lamp-desk': ['Small mushroom lamp beside a laptop on a tidy minimalist desk', 'A tidy minimalist desk setup with a small mushroom table lamp glowing beside a laptop, a ceramic mug, a notebook and a trailing plant'],
  'lamp-living': ['Mushroom lamp on a console table in a warm living room', 'A mushroom table lamp glowing on an oak console table in a warm neutral living room, styled with a ceramic vase and stacked art books'],
  'lamp-closeup': ['Close-up of a mushroom table lamp casting a soft warm glow', 'Close-up of a mushroom table lamp glowing softly, warm light falling across a textured plaster wall, shallow depth of field'],
  'lamp-reading': ['Cozy reading corner with an armchair and a small mushroom lamp', 'A cozy reading corner with a linen armchair, a chunky knit throw and a small side table holding a glowing mushroom lamp and a cup of tea'],
  'lamp-collage': ['Three rooms lit by mushroom lamps in a vertical collage', 'A vertical three-panel photo collage of a mushroom lamp styled in a bedroom, on a desk and in a living room, consistent warm palette, thin ivory gutters'],
  'cat-lighting': ['Warm lamplight glowing in a cozy neutral room'],
  'cat-bedroom': ['Layered neutral bedding in soft morning light'],
  'cat-decor': ['Ceramic vase and books styled on a wooden shelf'],
  'cat-desk-setup': ['Calm minimalist desk with a plant and a lamp'],
  'cat-organization': ['Neat woven baskets on a bright shelf'],
  'cat-gift-ideas': ['Beautifully wrapped gifts with dried flowers'],
  'cat-lifestyle': ['Morning coffee on a tray beside a sunlit window'],
  'cat-amazon-finds': ['Styled shelf of small home finds in warm light'],
  'inspo-1': ['Linen curtains and warm sunlight in a quiet bedroom'],
  'inspo-2': ['Stacked books, candle and tray on a walnut side table'],
  'inspo-3': ['Cozy window seat with cushions and a knit throw'],
  'inspo-4': ['Rattan pendant light over a neutral dining nook'],
};

// Upcoming stories show as "Coming soon" cards on the homepage. When one is written,
// move it into `articles`.
export const planned = [
  { title: '7 Cozy Bedroom Finds That Make Your Room Feel Expensive', cat: 'bedroom', desc: 'Small, thoughtful upgrades that give a bedroom a layered, boutique feel.' },
  { title: 'Best Desk Lamps for Small Spaces', cat: 'lighting', desc: 'Compact lamps that light a workspace well without crowding the desk.' },
  { title: '10 Amazon Finds for a Cozy Apartment', cat: 'amazon-finds', desc: 'Easy additions that make a rental feel warmer and more lived-in.' },
  { title: 'Small Bedroom Decor Ideas That Actually Work', cat: 'bedroom', desc: 'Smart ways to style a small bedroom without adding clutter.' },
  { title: 'Best Aesthetic Room Decor Under $50', cat: 'decor', desc: 'Affordable pieces that add style without a big spend.' },
];

export const articles = [
  {
    slug: 'why-mushroom-lamps-are-everywhere',
    title: 'Why Mushroom Lamps Are Everywhere Right Now — And How To Style One',
    short: 'Why Mushroom Lamps Are Everywhere Right Now',
    seoTitle: 'Mushroom Lamps: Why They’re Everywhere & How To Style One',
    desc: 'Why the mushroom lamp is everywhere, how to style one in your bedroom, desk and living room, and what to check before you buy.',
    dek: 'The softly glowing dome lamp is the cozy-room staple of the moment. Here is how to make it work in your home.',
    cats: ['lighting', 'bedroom', 'decor', 'amazon-finds'],
    date: '2026-10-17',
    hero: 'lamp-bedroom',
    feature: 'lamp-closeup',
    intro: `<p>Scroll through any cozy-room feed and you will spot it: a softly glowing, dome-capped lamp that looks half toadstool, half night-light. The <strong>mushroom lamp</strong> has gone from novelty to bedside staple, and it is easy to see why. Here is what it is, why it caught on, where it looks best, and what to check before you buy.</p>`,
    sections: [
      { id: 'what-is', h: 'What Is a Mushroom Lamp?', img: 'lamp-closeup', body: `<p>A mushroom lamp is a small table lamp shaped like a mushroom: a rounded cap that spreads the light and a short stem that doubles as the base. A <strong>mushroom table lamp</strong> can be made of glass, resin, ceramic, fabric or frosted plastic, and many modern versions use built-in LEDs. Most are designed for a nightstand, desk or shelf rather than the floor.</p>` },
      { id: 'trending', h: 'Why Are Mushroom Lamps Trending?', body: `<p>Three things helped. The shape is photogenic, so it travels well on Pinterest and in short videos. The rounded dome feels playful without being childish, which suits retro-modern and soft, nature-inspired rooms alike. And it is small and easy to buy, so a lamp is one of the simplest ways to change a room’s mood without renovating.</p><p>Trends cool, but an <strong>aesthetic mushroom lamp</strong> is not tied to one style, which makes it easier to keep using after the hype fades.</p>` },
      { id: 'cozy-light', h: 'Why They Create Cozy Lighting', body: `<p>Cozy light is low, warm and indirect. A domed shade scatters the glow softly instead of aiming a beam, and a lamp sitting close to the surface keeps the light below eye level, which feels calmer than a ceiling fixture. That is the secret behind <a href="/category/lighting">cozy bedroom lighting</a> that actually helps you wind down.</p><p>When you shop, look for a warm white bulb or LED (often listed around 2700K) and, ideally, a dimmer or several brightness settings. Switching off the overhead light in the evening does most of the work.</p>` },
      { id: 'placement', h: 'Where To Put A Mushroom Lamp', img: 'lamp-reading', body: `<p>Think low and close: nightstands, desks, shelves, sideboards and window ledges all work. Leave a little breathing room around the lamp so the glow can spread, and keep it clear of curtains and anything delicate.</p><p>If a spot already has a task lamp or a bright overhead light, use the mushroom lamp as the soft accent that finishes the corner.</p>` },
      { id: 'bedroom', h: 'Bedroom Styling', body: `<p>A mushroom lamp bedroom look starts at the nightstand, where a small, cute bedside lamp adds charm without taking over.</p><h3>On the nightstand</h3><p>Pair the lamp with a short stack of books and a small tray so it looks intentional. Keep the palette soft: creams, warm woods and one muted accent.</p><h3>On a dresser or shelf</h3><p>Place the lamp toward one end and balance it with a plant, a candle or a framed print. Add a textured throw and turn off the overhead light at night for the full effect. For more ideas, browse our <a href="/category/bedroom">bedroom stories</a>.</p>` },
      { id: 'desk', h: 'Desk Styling', img: 'lamp-desk', body: `<p>A mushroom lamp is a mood light, not a task light. Use it as a soft accent beside the monitor and keep a proper desk lamp for reading and detailed work.</p><p>Tame the cable with a clip or adhesive hook, then keep the rest of the surface calm: one plant, one tray, one notebook.</p>` },
      { id: 'living-room', h: 'Living Room Styling', img: 'lamp-living', body: `<p>On a console, side table or bookshelf, the lamp adds a low pool of light that makes evenings feel softer. Style it as a small vignette: something taller behind it, such as a vase or framed print, and something lower beside it, like a bowl or a stack of books.</p><p>It is an easy piece of <a href="/category/decor">aesthetic room decor</a>: a matching pair on a sideboard looks more formal, while a single lamp feels relaxed.</p>` },
      { id: 'buying-guide', h: 'What To Look For Before Buying', body: `<ul><li><strong>Light color and brightness:</strong> warm white suits bedrooms, and dimming adds flexibility.</li><li><strong>Power:</strong> check whether it plugs in or recharges, the cord length, and where the switch sits.</li><li><strong>Materials and finish:</strong> glass, resin, ceramic and fabric look different in person, so read the care notes.</li><li><strong>Size:</strong> compare the listed dimensions with your nightstand or shelf.</li><li><strong>Reviews and returns:</strong> check recent customer photos and the return policy.</li></ul>` },
      { id: 'featured', h: 'Featured Product', body: `<p>Our featured pick goes here. Always check the listing for current price, size, reviews and availability before you buy.</p>`, product: { name: '[Product name]', blurb: '[Add why you chose it: size, finish and light color, taken from the real listing.]', url: '[AMAZON PRODUCT LINK]' } },
      { id: 'pros-cons', h: 'Pros &amp; Cons', pros: ['Soft, flattering glow', 'Compact and easy to move', 'Works in bedrooms, offices and living rooms', 'A simple way to refresh a room'], cons: ['Often too dim for reading or tasks', 'Quality and finish vary by listing', 'Novelty shapes can date'] },
      { id: 'faq', h: 'Frequently Asked Questions', faq: true },
      { id: 'final', h: 'Final Recommendation', img: 'lamp-collage', body: `<p>If you want to try the trend, start in the room where you most want a softer evening, usually the bedroom. Pick a size that fits your surface, a warm light you can dim, and a shape you will still like next year.</p><p>Looking for more? Explore <a href="/category/lighting">cozy lighting</a> and <a href="/category/amazon-finds">Amazon finds</a>.</p>` },
    ],
    faq: [
      ['Are mushroom lamps good for bedrooms?', 'Yes. The soft, low glow suits a bedside table, especially in a warm white. Choose a dimmable or low-brightness model if you want to wind down with it.'],
      ['Can I read by a mushroom lamp?', 'Some give enough light for a few pages, but most are designed for ambience. If you read often, pair it with a dedicated reading light.'],
      ['Where can I buy a mushroom lamp?', 'Mushroom lamps are sold by home retailers and on Amazon in many styles. Whether you choose an Amazon mushroom lamp or one from a local shop, compare dimensions, light color and recent reviews first.'],
      ['How do I style one without it feeling childish?', 'Stick to a neutral palette, natural textures such as wood and linen, and keep the surrounding accessories minimal.'],
    ],
  },
];
